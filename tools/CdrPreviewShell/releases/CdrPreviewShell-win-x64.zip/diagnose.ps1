$ErrorActionPreference = "Continue"

$thumbClsid = "{7e2d1a0b-3c4d-5e6f-7a8b-9c0d1e2f3a4b}"
$iconClsid = "{6d1c0a9b-2b3c-4d4e-5f6a-7b8c9d0e1f2a}"
$shellExThumb = "{E357FCCD-A995-4576-B01F-234630154E96}"
$approvedKey = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved"
$logPath = Join-Path $env:LOCALAPPDATA "CdrPreviewShell\handler.log"

Write-Host "CDR Preview Shell diagnostics" -ForegroundColor Cyan
Write-Host ""

function Show-RegValue {
    param([string]$Label, [string]$Path)

    Write-Host $Label -ForegroundColor Yellow
    if (-not (Test-Path $Path)) {
        Write-Host "  (missing)" -ForegroundColor Red
        Write-Host ""
        return
    }

    try {
        $item = Get-ItemProperty -Path $Path -ErrorAction Stop
        $item.PSObject.Properties |
            Where-Object { $_.Name -notmatch '^PS' } |
            ForEach-Object { Write-Host ("  {0} = {1}" -f $_.Name, $_.Value) }
    }
    catch {
        Write-Host "  (unreadable)" -ForegroundColor Red
    }

    Write-Host ""
}

function Show-DefaultIconCheck {
    param([string]$Label, [string]$Path)

    Write-Host $Label -ForegroundColor Yellow
    if (-not (Test-Path $Path)) {
        Write-Host "  (missing) - icon handler will NOT run" -ForegroundColor Red
        Write-Host ""
        return
    }

    $value = (Get-ItemProperty -Path $Path -Name "(default)" -ErrorAction SilentlyContinue).'(default)'
    Write-Host "  (default) = $value"
    if ($value -eq "%1") {
        Write-Host "  OK" -ForegroundColor Green
    }
    else {
        Write-Host "  WRONG - must be %1 for per-file icons" -ForegroundColor Red
    }

    Write-Host ""
}

$progId = (Get-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\.cdr" -Name "(default)" -ErrorAction SilentlyContinue).'(default)'
$userProgId = $null
$userChoicePath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.cdr\UserChoice"
if (Test-Path $userChoicePath) {
    $userProgId = (Get-ItemProperty -Path $userChoicePath -Name "ProgId" -ErrorAction SilentlyContinue).ProgId
}

Write-Host "Resolved ProgIDs:" -ForegroundColor Cyan
Write-Host "  .cdr -> $progId"
Write-Host "  UserChoice -> $userProgId"
Write-Host ""

Show-DefaultIconCheck ".cdr DefaultIcon" "Registry::HKEY_CLASSES_ROOT\.cdr\DefaultIcon"
Show-DefaultIconCheck "SystemFileAssociations .cdr DefaultIcon" "Registry::HKEY_CLASSES_ROOT\SystemFileAssociations\.cdr\DefaultIcon"
if ($progId -and $progId -ne ".cdr") {
    Show-DefaultIconCheck "ProgID DefaultIcon ($progId)" "Registry::HKEY_CLASSES_ROOT\$progId\DefaultIcon"
}
if ($userProgId) {
    Show-DefaultIconCheck "User ProgID DefaultIcon ($userProgId)" "Registry::HKEY_CLASSES_ROOT\$userProgId\DefaultIcon"
}

Show-RegValue ".cdr icon handler" "Registry::HKEY_CLASSES_ROOT\.cdr\ShellEx\IconHandler"
Show-RegValue ".cdr thumbnail ShellEx" "Registry::HKEY_CLASSES_ROOT\.cdr\ShellEx\$shellExThumb"
Show-RegValue "SystemFileAssociations .cdr icon" "Registry::HKEY_CLASSES_ROOT\SystemFileAssociations\.cdr\ShellEx\IconHandler"
Show-RegValue "SystemFileAssociations .cdr thumbnail" "Registry::HKEY_CLASSES_ROOT\SystemFileAssociations\.cdr\ShellEx\$shellExThumb"

if ($progId -and $progId -ne ".cdr") {
    Show-RegValue "ProgID icon handler ($progId)" "Registry::HKEY_CLASSES_ROOT\$progId\ShellEx\IconHandler"
    Show-RegValue "ProgID thumbnail ($progId)" "Registry::HKEY_CLASSES_ROOT\$progId\ShellEx\$shellExThumb"
}

Show-RegValue "Thumbnail InprocServer32" "Registry::HKEY_CLASSES_ROOT\CLSID\$thumbClsid\InprocServer32"
Show-RegValue "Icon InprocServer32" "Registry::HKEY_CLASSES_ROOT\CLSID\$iconClsid\InprocServer32"

$codeBase = (Get-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\CLSID\$thumbClsid\InprocServer32" -Name "CodeBase" -ErrorAction SilentlyContinue).CodeBase
Write-Host "Registered CodeBase:" -ForegroundColor Yellow
Write-Host "  $codeBase"
if ($codeBase -match "OneDrive|Desktop|Downloads") {
    Write-Host "  WARNING: DLL is on OneDrive/Desktop. Re-run install.bat to copy to Program Files." -ForegroundColor Red
}
Write-Host ""

$installedPath = (Get-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\CdrPreviewShell" -Name "InstallPath" -ErrorAction SilentlyContinue).InstallPath
Write-Host "InstallPath marker:" -ForegroundColor Yellow
Write-Host "  $installedPath"
Write-Host ""

Show-RegValue "cdr.1 PerceivedType" "Registry::HKEY_CLASSES_ROOT\cdr.1"
Show-RegValue "Approved sample" $approvedKey

$dll = Join-Path $PSScriptRoot "CdrPreviewShell.dll"
Write-Host "Local DLL:" -ForegroundColor Yellow
if (Test-Path $dll) {
    Write-Host "  $dll"
    Write-Host ("  modified: {0}" -f (Get-Item $dll).LastWriteTime)
}
else {
    Write-Host "  (missing)" -ForegroundColor Red
}

Write-Host ""
Write-Host "Handler log ($logPath):" -ForegroundColor Yellow
if (Test-Path $logPath) {
    Get-Content $logPath -Tail 30 | ForEach-Object { Write-Host "  $_" }
    Write-Host ""
    if ((Get-Content $logPath | Measure-Object -Line).Lines -eq 0) {
        Write-Host "Log file exists but is empty." -ForegroundColor Red
    }
}
else {
    Write-Host "  (no log yet)" -ForegroundColor Red
}

Write-Host ""
Write-Host "If no 'type loaded' lines in log:" -ForegroundColor Yellow
Write-Host "  Windows did not load the .NET handlers (COM activation failed)." -ForegroundColor Yellow
Write-Host "  Fix: run install.bat again (copies to Program Files, unblocks DLL)." -ForegroundColor Yellow
Write-Host "  Then open .cdr folder in Extra large icons and run diagnose again." -ForegroundColor Yellow

Write-Host ""
Write-Host "Expected icon CLSID: $iconClsid" -ForegroundColor Green
Write-Host "Expected thumbnail CLSID: $thumbClsid" -ForegroundColor Green
