$ErrorActionPreference = "Stop"

$installMarker = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\CdrPreviewShell"
$installDir = $null
if (Test-Path $installMarker) {
    $installDir = (Get-ItemProperty -Path $installMarker -Name "InstallPath" -ErrorAction SilentlyContinue).InstallPath
}
if (-not $installDir) {
    $installDir = Join-Path $env:ProgramFiles "CdrPreviewShell"
}
if (-not (Test-Path (Join-Path $installDir "CdrPreviewShell.dll"))) {
    $installDir = $PSScriptRoot
}

$dll = Join-Path $installDir "CdrPreviewShell.dll"
$regasm = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"

if (-not (Test-Path $dll)) {
    throw "CdrPreviewShell.dll not found"
}
if (-not (Test-Path $regasm)) {
    throw "RegAsm.exe not found"
}

Write-Host "Unregistering from $installDir ..." -ForegroundColor Cyan
& $regasm /unregister $dll | Out-String | Write-Host

Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Get-Process -Name dllhost -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2
Start-Process explorer

Write-Host "Uninstalled." -ForegroundColor Green
