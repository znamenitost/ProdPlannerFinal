$ErrorActionPreference = "Stop"

$sourceDir = $PSScriptRoot
$installDir = Join-Path $env:ProgramFiles "CdrPreviewShell"
$installMarker = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\CdrPreviewShell"
$regasm = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
$thumbClsid = "{7e2d1a0b-3c4d-5e6f-7a8b-9c0d1e2f3a4b}"
$iconClsid = "{6d1c0a9b-2b3c-4d4e-5f6a-7b8c9d0e1f2a}"
$shellExThumb = "{E357FCCD-A995-4576-B01F-234630154E96}"
$approvedKey = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved"

if (-not (Test-Path (Join-Path $sourceDir "CdrPreviewShell.dll"))) {
    throw "CdrPreviewShell.dll not found in $sourceDir"
}
if (-not (Test-Path $regasm)) {
    throw ".NET Framework 4.8 x64 not found (RegAsm.exe is missing)"
}

function Set-ThumbnailAssociation {
    param([string]$ClassKey)

    if ([string]::IsNullOrWhiteSpace($ClassKey)) {
        return
    }

    $shellExPath = "Registry::HKEY_CLASSES_ROOT\$ClassKey\ShellEx\$shellExThumb"
    if (-not (Test-Path $shellExPath)) {
        New-Item -Path $shellExPath -Force | Out-Null
    }

    Set-ItemProperty -Path $shellExPath -Name "(default)" -Value $thumbClsid -Force
}

function Set-IconHandlerAssociation {
    param([string]$ClassKey)

    if ([string]::IsNullOrWhiteSpace($ClassKey)) {
        return
    }

    $iconHandlerPath = "Registry::HKEY_CLASSES_ROOT\$ClassKey\ShellEx\IconHandler"
    if (-not (Test-Path $iconHandlerPath)) {
        New-Item -Path $iconHandlerPath -Force | Out-Null
    }

    Set-ItemProperty -Path $iconHandlerPath -Name "(default)" -Value $iconClsid -Force

    $defaultIconPath = "Registry::HKEY_CLASSES_ROOT\$ClassKey\DefaultIcon"
    if (-not (Test-Path $defaultIconPath)) {
        New-Item -Path $defaultIconPath -Force | Out-Null
    }

    $currentDefault = (Get-ItemProperty -Path $defaultIconPath -Name "(default)" -ErrorAction SilentlyContinue).'(default)'
    if ($currentDefault -and $currentDefault -ne "%1") {
        if (-not (Get-ItemProperty -Path $defaultIconPath -Name "CdrPreviewShellBackup" -ErrorAction SilentlyContinue)) {
            New-ItemProperty -Path $defaultIconPath -Name "CdrPreviewShellBackup" -Value $currentDefault -Force | Out-Null
        }
    }

    Set-ItemProperty -Path $defaultIconPath -Name "(default)" -Value "%1" -Force
}

function Register-CdrAssociations {
    param([string]$ClassKey)

    Set-ThumbnailAssociation $ClassKey
    Set-IconHandlerAssociation $ClassKey
}

function Approve-ShellExtension {
    param(
        [string]$Clsid,
        [string]$Name
    )

    if (-not (Test-Path $approvedKey)) {
        New-Item -Path $approvedKey -Force | Out-Null
    }

    Set-ItemProperty -Path $approvedKey -Name $Clsid -Value $Name -Force
}

function Set-DisableProcessIsolation {
    param([string]$ClsidPath)
    if (-not (Test-Path $ClsidPath)) {
        New-Item -Path $ClsidPath -Force | Out-Null
    }
    New-ItemProperty -Path $ClsidPath -Name "DisableProcessIsolation" -Value 1 -PropertyType DWord -Force | Out-Null
}

function Stop-ShellExtensionHosts {
    Write-Host "Stopping Explorer and shell extension hosts..." -ForegroundColor Cyan
    Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
    Get-Process -Name dllhost -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-Process -Name prevhost -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Seconds 2
}

Write-Host "Preparing installation..." -ForegroundColor Cyan
Stop-ShellExtensionHosts

$existingDll = Join-Path $installDir "CdrPreviewShell.dll"
if (Test-Path $existingDll) {
    Write-Host "Unregistering previous registration..." -ForegroundColor Cyan
    & $regasm /unregister $existingDll 2>$null | Out-Null
    Stop-ShellExtensionHosts
}

Write-Host "Installing to $installDir ..." -ForegroundColor Cyan
New-Item -ItemType Directory -Path $installDir -Force | Out-Null

$copyAttempt = 0
while ($copyAttempt -lt 3) {
    try {
        Get-ChildItem -Path $sourceDir -File | Copy-Item -Destination $installDir -Force
        break
    }
    catch {
        $copyAttempt++
        if ($copyAttempt -ge 3) {
            throw
        }
        Write-Host "Files are locked, stopping hosts again (attempt $copyAttempt/3)..." -ForegroundColor Yellow
        Stop-ShellExtensionHosts
    }
}

Get-ChildItem -Path $installDir -Include *.dll,*.config -File | ForEach-Object {
    Unblock-File -Path $_.FullName -ErrorAction SilentlyContinue
}

$dll = Join-Path $installDir "CdrPreviewShell.dll"

Write-Host "Registering CDR Preview Shell..." -ForegroundColor Cyan
& $regasm /codebase $dll | Out-String | Write-Host

if (-not (Test-Path $installMarker)) {
    New-Item -Path $installMarker -Force | Out-Null
}
Set-ItemProperty -Path $installMarker -Name "InstallPath" -Value $installDir -Force

Write-Host "Approving shell extensions..." -ForegroundColor Cyan
Approve-ShellExtension $thumbClsid "CDR File Thumbnail"
Approve-ShellExtension $iconClsid "CDR File Icon"

Set-DisableProcessIsolation "Registry::HKEY_CLASSES_ROOT\CLSID\$thumbClsid"
Set-DisableProcessIsolation "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\$thumbClsid"

Write-Host "Registering .cdr thumbnail and icon handlers..." -ForegroundColor Cyan
$associationKeys = @(".cdr", "SystemFileAssociations\.cdr")
$progId = (Get-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\.cdr" -Name "(default)" -ErrorAction SilentlyContinue).'(default)'
if ($progId -and $progId -ne ".cdr") {
    $associationKeys += $progId
}

foreach ($key in $associationKeys) {
    Register-CdrAssociations $key
}

Write-Host "Clearing icon/thumbnail cache..." -ForegroundColor Cyan

$thumbCacheDir = Join-Path $env:LOCALAPPDATA "Microsoft\Windows\Explorer"
Get-ChildItem -Path $thumbCacheDir -Filter "thumbcache_*.db" -ErrorAction SilentlyContinue |
    Remove-Item -Force -ErrorAction SilentlyContinue
Get-ChildItem -Path $thumbCacheDir -Filter "iconcache_*.db" -ErrorAction SilentlyContinue |
    Remove-Item -Force -ErrorAction SilentlyContinue

$logDir = Join-Path $env:LOCALAPPDATA "CdrPreviewShell"
if (Test-Path (Join-Path $logDir "handler.log")) {
    Remove-Item (Join-Path $logDir "handler.log") -Force -ErrorAction SilentlyContinue
}

Start-Process explorer

Write-Host ""
Write-Host "Installed to: $installDir" -ForegroundColor Green
Write-Host "Do NOT run from Desktop/OneDrive zip after install." -ForegroundColor Yellow
Write-Host "1. Open folder with .cdr files" -ForegroundColor Green
Write-Host "2. View -> Extra large icons (or Medium icons)" -ForegroundColor Green
Write-Host "3. Run diagnose.bat and check handler.log" -ForegroundColor Green
