$ErrorActionPreference = "Continue"

function Test-ComClass {
    param(
        [string]$Label,
        [string]$Clsid
    )

    Write-Host $Label -ForegroundColor Cyan
    Write-Host "  CLSID: $Clsid"

    try {
        $type = [Type]::GetTypeFromCLSID($Clsid)
        if ($null -eq $type) {
            Write-Host "  GetTypeFromCLSID returned null" -ForegroundColor Red
            Write-Host ""
            return
        }

        Write-Host "  Type: $($type.FullName)" -ForegroundColor Green
        $obj = [Activator]::CreateInstance($type)
        Write-Host "  CreateInstance: OK" -ForegroundColor Green
        Write-Host "  Object: $($obj.GetType().FullName)" -ForegroundColor Green
    }
    catch {
        Write-Host "  FAILED: $($_.Exception.Message)" -ForegroundColor Red
        $inner = $_.Exception.InnerException
        while ($null -ne $inner) {
            Write-Host "  Inner: $($inner.Message)" -ForegroundColor Red
            $inner = $inner.InnerException
        }
    }

    Write-Host ""
}

Write-Host "COM activation test (same as Explorer would do)" -ForegroundColor Yellow
Write-Host ""

Test-ComClass "Thumbnail handler" "{7e2d1a0b-3c4d-5e6f-7a8b-9c0d1e2f3a4b}"
Test-ComClass "Icon handler" "{6d1c0a9b-2b3c-4d4e-5f6a-7b8c9d0e1f2a}"
Test-ComClass "Preview handler (works in pane)" "{8f3e2a1b-4c5d-6e7f-8a9b-0c1d2e3f4a5b}"

$logPath = Join-Path $env:LOCALAPPDATA "CdrPreviewShell\handler.log"
if (Test-Path $logPath) {
    Write-Host "Handler log after COM test:" -ForegroundColor Yellow
    Get-Content $logPath -Tail 10 | ForEach-Object { Write-Host "  $_" }
}
else {
    Write-Host "Handler log still empty after COM test." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Send this full output if thumbnails still fail." -ForegroundColor Green
